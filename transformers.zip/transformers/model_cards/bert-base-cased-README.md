---
tags:
- exbert
---

<a href="https://huggingface.co/exbert/?model=bert-base-cased">
	<img width="300px" src="https://hf-dinosaur.huggingface.co/exbert/button.png">
</a>
