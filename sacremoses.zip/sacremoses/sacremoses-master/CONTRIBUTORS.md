Contributors
====

 |Contributor | Pull Request / Issue |
 |:-|:-|
 | [Bo Li](https://github.com/askender)             | #5, #6 |
 | [Patrick Düggelin](https://github.com/Patdue)    | #9 |
 | [Myle Ott](https://github.com/myleott) | #36 |
 | [David Harrison](https://github.com/DavidHarrison) | #41, #47 |
 | [yannvgn](https://github.com/yannvgn) | #56, #57 |
 | [BLKSerene](https://github.com/BLKSerene) | #66 |
 | [Shijie Wu](https://github.com/shijie-wu) | #67 |
 | [Matt Post](https://github.com/mjpost) | #69 |
 | [brandonherzog](brandonherzog) | #72 |
 
